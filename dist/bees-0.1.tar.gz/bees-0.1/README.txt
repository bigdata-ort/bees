Utility package for the bees project.
